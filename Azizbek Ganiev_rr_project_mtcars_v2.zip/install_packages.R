
pkgs <- c('ggplot2','dplyr','broom','testthat','readr','tidyr','stringr','knitr')
to_install <- pkgs[!(pkgs %in% rownames(installed.packages()))]
if(length(to_install)) install.packages(to_install, repos = 'https://cloud.r-project.org')
message('Packages ready.')
