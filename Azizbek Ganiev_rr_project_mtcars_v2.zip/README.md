
# Reproducible Research Project – *Determinants of Fuel Efficiency (mtcars)*

**Student:** Azizbek Ganiev (ID: 475150)  
**Professor:** Wojciech Hardy  
**Course:** Reproducible Research 2025

This repository demonstrates best practices in **reproducible research** using **R** and **Quarto** on a small, stable dataset (`mtcars` from base R).

It includes:
- Parameterized Quarto reports with **code + narrative + results**.
- A clean folder structure and **Makefile/pipeline** to reproduce results end-to-end.
- **R functions** in `R/` with **unit tests** in `tests/` (`testthat`).
- Version control hygiene (`.gitignore`, meaningful commit messages).
- An installation script to set up required packages.

> You can use this as a new project for your retake. Everything is self-contained and does not require internet data downloads.

## Quick Start

1. Install R (≥ 4.2) and Quarto.
2. Open R and run:
```r
source('install_packages.R')
```
3. Reproduce everything:
```sh
make all
```
Or render analysis only:
```sh
quarto render analysis
```

## Project Structure

```
analysis/            # Quarto reports
  _quarto.yml
  01_explore.qmd
  02_model.qmd
data/
  raw/               # (empty; using built-in mtcars)
  processed/         # generated tables/figures (ignored in Git)
R/                   # Reusable functions
  load_data.R
  clean_data.R
  model_mpg.R
  plot_utils.R
scripts/
  run_all.R          # pipeline to run everything
tests/
  testthat/
    test_clean_data.R
  testthat.R
Makefile             # build pipeline
install_packages.R   # lightweight dependencies
CITATION.cff         # citation metadata
LICENSE
README.md
```

## Reproducibility Notes
- Reports capture **session info** and the exact **package versions**.
- Analyses are **parameterized** (e.g., filter to a transmission type) for easy re-execution.
- Unit tests check that cleaning and modeling behave as expected.
