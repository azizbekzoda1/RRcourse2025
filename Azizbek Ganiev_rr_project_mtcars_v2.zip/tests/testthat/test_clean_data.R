
test_that('clean_data factors and columns exist', {
  df <- load_data()
  cl <- clean_data(df)
  expect_true(is.factor(cl$cyl))
  expect_true(is.factor(cl$am))
  expect_true(all(c('model','mpg','hp','weight') %in% names(cl)))
})
