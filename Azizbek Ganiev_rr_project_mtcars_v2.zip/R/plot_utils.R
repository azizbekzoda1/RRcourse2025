
#' Create a scatter plot of mpg vs hp colored by transmission
#' @param df Cleaned data frame
#' @return ggplot object
plot_mpg_hp <- function(df){
  ggplot2::ggplot(df, ggplot2::aes(x = hp, y = mpg, shape = am)) +
    ggplot2::geom_point(size = 3) +
    ggplot2::geom_smooth(method = 'lm', se = TRUE) +
    ggplot2::labs(x = 'Horsepower', y = 'Miles per gallon', shape = 'Transmission')
}
