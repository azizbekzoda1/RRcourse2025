
#' Clean and prepare mtcars
#' @param df A data frame like from load_data()
#' @return Cleaned tibble
clean_data <- function(df){
  stopifnot(is.data.frame(df))
  dplyr::mutate(df,
                cyl = factor(cyl),
                am  = factor(am, labels = c('Automatic','Manual')),
                vs  = factor(vs, labels = c('V','Straight'))) |>
    dplyr::rename(mpg = mpg, hp = hp, weight = wt) |>
    dplyr::relocate(model, mpg, cyl, am, hp, weight)
}
