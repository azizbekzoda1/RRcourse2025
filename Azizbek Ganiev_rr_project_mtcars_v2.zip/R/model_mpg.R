
#' Fit linear model predicting mpg
#' @param df Cleaned data frame
#' @param include_interaction logical; include am:hp interaction
#' @return list(model = lm-object, tidy = tibble)
fit_mpg_model <- function(df, include_interaction = TRUE){
  stopifnot(is.data.frame(df))
  if(include_interaction){
    fit <- lm(mpg ~ hp*am + weight + cyl, data = df)
  } else {
    fit <- lm(mpg ~ hp + am + weight + cyl, data = df)
  }
  list(model = fit, tidy = broom::tidy(fit, conf.int = TRUE))
}
