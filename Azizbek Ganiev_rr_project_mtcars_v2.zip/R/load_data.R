
#' Load the mtcars dataset as a tibble
#' @return A tibble with car specs
load_data <- function() {
  tibble::as_tibble(mtcars, rownames = "model")
}
