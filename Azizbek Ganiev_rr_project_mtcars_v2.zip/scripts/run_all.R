
source('R/load_data.R')
source('R/clean_data.R')
source('R/model_mpg.R')
source('R/plot_utils.R')

df  <- load_data() |> clean_data()
mod <- fit_mpg_model(df)

dir.create('data/processed', showWarnings = FALSE, recursive = TRUE)
readr::write_csv(mod$tidy, 'data/processed/model_summary.csv')

dir.create('outputs', showWarnings = FALSE)
ggplot2::ggsave('outputs/mpg_hp.png', plot = plot_mpg_hp(df), width = 6, height = 4, dpi = 300)

message('Pipeline complete.')
